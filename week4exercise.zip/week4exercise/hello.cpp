#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;

    std::cout << "My name is JUNG SEUNG WOO." << std::endl;

    int num1 = 5;
    int num2 = 7;
    int sum = num1 + num2;
    std::cout << "The sum of " << num1 << " and " << num2 << " is: " << sum << std::endl;

    return 0;
}
