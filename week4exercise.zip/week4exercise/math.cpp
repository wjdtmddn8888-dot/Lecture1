// math.cpp

#include "math.h"


int add(int a, int b) {
    return a + b;
}


int add(int a, int b, int c) {
    return a + b + c;
}


double add(double a, double b) {
    return a + b;
}


int multiply(int a, int b) {
    return a * b;
}
