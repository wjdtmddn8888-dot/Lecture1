// main.cpp

#include <iostream>
#include "math.h"

int main() {
    int num1, num2;

   
    std::cout << "Enter the first integer: ";
    std::cin >> num1;
    std::cout << "Enter the second integer: ";
    std::cin >> num2;

 
    int sum_result = add(num1, num2);
    std::cout << "\n--- Basic Results ---" << std::endl;
    std::cout << "The sum of " << num1 << " and " << num2 << " is: " << sum_result << std::endl;

  
    int product_result = multiply(num1, num2);
    std::cout << "The product of " << num1 << " and " << num2 << " is: " << product_result << std::endl;


    int num3 = 10;
    int sum_three_result = add(num1, num2, num3);
    std::cout << "\n--- Overloading Results ---" << std::endl;
    std::cout << "The sum of " << num1 << ", " << num2 << ", and " << num3 << " is: " << sum_three_result << std::endl;


    double d1 = 3.5;
    double d2 = 2.5;
    double sum_double_result = add(d1, d2);
    std::cout << "The sum of " << d1 << " and " << d2 << " (doubles) is: " << sum_double_result << std::endl;

    return 0;
}
